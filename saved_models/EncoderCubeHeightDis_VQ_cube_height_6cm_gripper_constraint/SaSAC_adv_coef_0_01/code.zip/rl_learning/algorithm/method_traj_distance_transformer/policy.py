from typing import Any, Dict, List, Optional, Tuple, Type, Union
import numpy as np
from copy import deepcopy

import torch as th
import torch
from gymnasium import spaces
from torch import nn
import matplotlib.pyplot as plt
import seaborn as sns
import os
import math
from .iTransformer import ITransformer


class Config:
    """Configuration class for ITransformer"""
    def __init__(self, task_name, seq_len, pred_len, d_model, embed, freq, dropout,
                 factor, n_heads, d_ff, e_layers, activation, enc_in, num_class):
        self.task_name = task_name
        self.seq_len = seq_len
        self.pred_len = pred_len
        self.d_model = d_model
        self.embed = embed
        self.freq = freq
        self.dropout = dropout
        self.factor = factor
        self.n_heads = n_heads
        self.d_ff = d_ff
        self.e_layers = e_layers
        self.activation = activation
        self.enc_in = enc_in
        self.num_class = num_class


from stable_baselines3.common.preprocessing import get_action_dim, is_image_space, maybe_transpose
from stable_baselines3.common.preprocessing import get_action_dim, get_obs_shape
from stable_baselines3.common.torch_layers import (
    BaseFeaturesExtractor,
    CombinedExtractor,
)
from stable_baselines3.common.type_aliases import Schedule
from stable_baselines3.common.utils import is_vectorized_observation, obs_as_tensor


# CAP the standard deviation of the actor
LOG_STD_MAX = 2
LOG_STD_MIN = -20

from stable_baselines3.sac.policies import SACPolicy
from stable_baselines3.common.policies import BaseModel
from line_profiler import profile
# 
class Encoder(BaseModel):
    def __init__(
        self,
        observation_space: spaces.Space,
        action_space: spaces.Box,
        hidden_dim : int = 128,
        optimizer_kwargs: dict = {'eps':1e-5, 'lr':1e-3}
    ):
        super().__init__(
            observation_space,
            action_space,
            optimizer_kwargs=optimizer_kwargs
        )
        self.action_dim = get_action_dim(action_space)
        obs_shapes = get_obs_shape(observation_space)
        self.observation_dim = sum([obs_shape[0] for obs_shape in obs_shapes.values()])
        self.lstm = nn.LSTM(self.observation_dim-10, hidden_dim, 1,
                            bidirectional=False, batch_first=True, bias=False)
        self.fc = nn.Linear(hidden_dim,self.action_dim)
        self.weight_info_nce = nn.Linear(self.action_dim,self.action_dim,bias=False)
        
    @th.no_grad()
    def forward_one_step(self, x, h, c):
        """
        Obtain the causal representation of the next step during the trajectory collection
        """
        keys = list(x.keys())
        keys.remove('achieved_goal')
        keys.remove('desired_goal')
        keys.remove('action')
        keys.sort()
        x = th.cat(([x[_x] for _x in keys]),dim = -1).unsqueeze(1)
        h = th.cat(([h[_h] for _h in h]),dim = -1).unsqueeze(0)
        c = th.cat(([c[_c] for _c in c]),dim = -1).unsqueeze(0)
        batch_size = x.size(0)
        H,(h,c) = self.lstm(x, (h,c))
        logits = self.fc(th.relu(H)[np.arange(batch_size),0,:])
        return logits, (h.squeeze(0),c.squeeze(0))

    @profile
    def forward(self, obs):
        """
        Obtain the causal representation of entire trajectory during train
        """
        keys = list(obs.keys()) # keys = ['achieved_goal', 'desired_goal', 'observation', 'action']
        keys.remove('achieved_goal')
        keys.remove('desired_goal')
        keys.remove('action')
        keys.sort()
        x = th.cat(([obs[_x] for _x in keys]),dim = -1)
        H,(_,_) = self.lstm(x)
        logits = self.fc(th.relu(H))
        return logits

class EncoderCube(BaseModel):
    def __init__(
        self,
        observation_space: spaces.Space,
        action_space: spaces.Box,
        hidden_dim : int = 128,
        optimizer_kwargs: dict = {'eps':1e-5, 'lr':1e-3}
    ):
        super().__init__(
            observation_space,
            action_space,
            optimizer_kwargs=optimizer_kwargs
        )
        self.action_dim = get_action_dim(action_space)
        obs_shapes = get_obs_shape(observation_space)
        self.observation_dim = sum([obs_shape[0] for obs_shape in obs_shapes.values()])
        self.lstm = nn.LSTM(self.observation_dim - 14, hidden_dim, 1,
                            bidirectional=False, batch_first=True, bias=False)
        self.fc = nn.Linear(hidden_dim,self.action_dim)
        self.weight_info_nce = nn.Linear(self.action_dim,self.action_dim,bias=False)
        
    @th.no_grad()
    def forward_one_step(self, x, h, c):
        """
        Obtain the causal representation of the next step during the trajectory collection
        """
        keys = list(x.keys())
        keys.remove('achieved_goal')
        keys.remove('desired_goal')
        keys.remove('action')
        keys.sort()
        x = th.cat(([x[_x] for _x in keys]),dim = -1).unsqueeze(1)
        h = th.cat(([h[_h] for _h in h]),dim = -1).unsqueeze(0)
        c = th.cat(([c[_c] for _c in c]),dim = -1).unsqueeze(0)
        batch_size = x.size(0)
        # Slice features along last dimension before feeding to LSTM
        x_slice = x[:, :, 4:10]
        H,(h,c) = self.lstm(x_slice, (h,c))
        logits = self.fc(th.relu(H)[np.arange(batch_size),0,:])
        return logits, (h.squeeze(0),c.squeeze(0))

    @profile
    def forward(self, obs):
        """
        Obtain the causal representation of entire trajectory during train
        """
        keys = list(obs.keys()) # keys = ['achieved_goal', 'desired_goal', 'observation', 'action']
        keys.remove('achieved_goal')
        keys.remove('desired_goal')
        keys.remove('action')
        keys.sort()
        x = th.cat([obs[_x] for _x in keys], dim=-1)
        
        # 提取相关特征并通过Transformer
        x_slice = x[:, :, 4:10]
        H = self.transformer(x_slice)
        logits = self.fc(th.relu(H))
        return logits

class EncoderCubeHeight(BaseModel):
    def __init__(
        self,
        observation_space: spaces.Space,
        action_space: spaces.Box,
        hidden_dim: int = 128,
        optimizer_kwargs: dict = {'eps': 1e-5, 'lr': 1e-3}
    ):
        super().__init__(
            observation_space,
            action_space,
            optimizer_kwargs=optimizer_kwargs
        )
        self.action_dim = get_action_dim(action_space)
        obs_shapes = get_obs_shape(observation_space)
        self.observation_dim = sum([obs_shape[0] for obs_shape in obs_shapes.values()])
        
        # Configure the transformer
        self.config = Config(
            task_name='height_prediction',
            seq_len=1,  # Single step processing
            pred_len=1,
            d_model=hidden_dim,
            embed='timeF',
            freq='h',
            dropout=0.1,
            factor=5,
            n_heads=8,
            d_ff=hidden_dim * 4,
            e_layers=2,
            activation='gelu',
            enc_in=1,  # Single feature (height)
            num_class=self.action_dim
        )
        
        self.transformer = ITransformer(self.config)
        self.fc = nn.Linear(hidden_dim, self.action_dim)
        self.weight_info_nce = nn.Linear(self.action_dim, self.action_dim, bias=False)
        
    @th.no_grad()
    def forward_one_step(self, x, h, c):
        """
        Process a single step using the transformer
        """
        keys = list(x.keys())
        keys.remove('achieved_goal')
        keys.remove('desired_goal')
        keys.remove('action')
        keys.sort()
        
        # Extract and reshape height feature
        x = th.cat([x[_x] for _x in keys], dim=-1).unsqueeze(1)
        batch_size = x.size(0)
        height_feature = x[:, :, [2]]  # Extract height feature
        
        # Process through transformer
        transformed = self.transformer(height_feature)
        logits = self.fc(th.relu(transformed[:, -1, :]))  # Use the last sequence output
        
        # Return empty h, c as they're not used by transformer
        return logits, (None, None)

    def forward(self, obs):
        """
        Process the full sequence through the transformer
        """
        keys = list(obs.keys())
        keys.remove('achieved_goal')
        keys.remove('desired_goal')
        keys.remove('action')
        keys.sort()
        
        # Extract and process height feature
        x = th.cat([obs[_x] for _x in keys], dim=-1)
        height_feature = x[:, :, [2]]  # Extract height feature
        
        # Process through transformer
        transformed = self.transformer(height_feature)
        logits = self.fc(th.relu(transformed))
        return logits



class EncoderActionEffect(BaseModel):
    """
    Encoder for action effect, using ITransformer.
    This encoder processes the observation of cube.
    """
    def __init__(
        self,
        observation_space: spaces.Space,
        action_space: spaces.Box,
        hidden_dim: int = 128,
        optimizer_kwargs: dict = {'eps':1e-5, 'lr':1e-3}
    ):
        super().__init__(
            observation_space,
            action_space,
            optimizer_kwargs=optimizer_kwargs
        )
        self.action_dim = get_action_dim(action_space)
        obs_shapes = get_obs_shape(observation_space)
        self.observation_dim = sum([obs_shape[0] for obs_shape in obs_shapes.values()])
        
        # Calculate input features dimension
        self.feature_dim = 6  # Number of features we use (4:10)
        
        # ITransformer configuration
        encoder_config = Config(
            task_name="classification",
            seq_len=1,  # Single step processing
            pred_len=1,
            d_model=hidden_dim,
            embed='fixed',  # Use fixed embedding for single-step
            freq='h',
            dropout=0.1,
            factor=5,
            n_heads=4,
            d_ff=hidden_dim * 4,
            e_layers=2,
            activation='gelu',
            enc_in=1,  # Use 1 for classification task since we process all features together
            num_class=self.action_dim
        )
        self.transformer = ITransformer(encoder_config)
        self.pre_transform = nn.Linear(self.feature_dim, hidden_dim)  # Add input projection
        self.transformer = ITransformer(encoder_config)
        self.weight_info_nce = nn.Linear(self.action_dim, self.action_dim, bias=False)
        
    @th.no_grad()
    def forward_one_step(self, x, h, c):
        """
        Obtain the causal representation of the next step during the trajectory collection
        """
        keys = list(x.keys())
        keys.remove('achieved_goal')
        keys.remove('desired_goal')
        keys.remove('action')
        keys.sort()
        x = th.cat([x[_x] for _x in keys], dim=-1).unsqueeze(1)
        h = th.cat(([h[_h] for _h in h]),dim = -1).unsqueeze(0)
        c = th.cat(([c[_c] for _c in c]),dim = -1).unsqueeze(0)
        
        # Extract relevant features
        x_slice = x[:, :, 4:10]  # Shape: [batch_size, 1, 6]
        
        # Project features to transformer dimension
        x_transformed = self.pre_transform(x_slice)  # Shape: [batch_size, 1, hidden_dim]
        
        # Forward through transformer for classification
        logits = self.transformer(x_transformed, None, None, None)
        
        # Create dummy states with same device as input
        dummy_h = th.zeros_like(h)
        dummy_c = th.zeros_like(c)
        
        return logits, (dummy_h.squeeze(0), dummy_c.squeeze(0))

    @profile
    def forward(self, obs):
        """
        Obtain the causal representation of entire trajectory during train
        """
        keys = list(obs.keys())
        keys.remove('achieved_goal')
        keys.remove('desired_goal')
        keys.remove('action')
        keys.sort()
        x = th.cat([obs[_x] for _x in keys], dim=-1)
        
        # Extract relevant features
        x_slice = x[:, :, 4:10]
        
        # Project features to transformer dimension
        x_transformed = self.pre_transform(x_slice)  # Shape: [batch_size, seq_len, hidden_dim]
        
        # Forward through ITransformer
        logits = self.transformer(x_transformed, None, None, None)
        return logits


class EncoderCubeObsAction(BaseModel):
    """
    Encoder for action effect, using ITransformer.
    This encoder processes the observation and action.
    """
    def __init__(
        self,
        observation_space: spaces.Space,
        action_space: spaces.Box,
        hidden_dim: int = 128,
        optimizer_kwargs: dict = {'eps':1e-5, 'lr':1e-3}
    ):
        super().__init__(
            observation_space,
            action_space,
            optimizer_kwargs=optimizer_kwargs
        )
        self.action_dim = get_action_dim(action_space)
        obs_shapes = get_obs_shape(observation_space)
        self.observation_dim = sum([obs_shape[0] for obs_shape in obs_shapes.values()])
        
        # Calculate input dimension (observation_dim - achieved_goal and desired_goal dims)
        input_dim = self.observation_dim - 6  # Remove achieved_goal and desired_goal dimensions
        
        # ITransformer configuration
        self.encoder_config = Config(
            task_name="classification",
            seq_len=1,  # Single step processing
            pred_len=1,
            d_model=hidden_dim,
            embed='fixed',
            freq='h',
            dropout=0.1,
            factor=5,
            n_heads=4,
            d_ff=hidden_dim * 4,
            e_layers=2,
            activation='gelu',
            enc_in=input_dim,
            num_class=self.action_dim
        )
        self.transformer = ITransformer(self.encoder_config)
        self.weight_info_nce = nn.Linear(self.action_dim, self.action_dim, bias=False)
        
    @th.no_grad()
    def forward_one_step(self, x, h, c):
        """
        Process a single step through the transformer
        """
        keys = list(x.keys())
        keys.remove('achieved_goal')
        keys.remove('desired_goal')
        # keys.remove('action')
        keys.sort()
        
        # Concatenate inputs and reshape for transformer
        x = th.cat([x[_x] for _x in keys], dim=-1).unsqueeze(1)  # [batch_size, 1, feature_dim]
        
        # Reshape input to match transformer's expected shape [batch_size, seq_len, enc_in]
        batch_size = x.size(0)
        x = x.reshape(batch_size, -1, self.encoder_config.enc_in)
        h = th.cat(([h[_h] for _h in h]),dim = -1).unsqueeze(0)
        c = th.cat(([c[_c] for _c in c]),dim = -1).unsqueeze(0)
        
        # Forward through ITransformer
        logits = self.transformer(x, None, None, None)
        
        # Create dummy states (transformer doesn't use LSTM states)
        dummy_h = th.zeros_like(h)
        dummy_c = th.zeros_like(c)
        
        return logits, (dummy_h.squeeze(0), dummy_c.squeeze(0))

    @profile
    def forward(self, obs):
        """
        Process the full trajectory through transformer
        """
        keys = list(obs.keys())
        keys.remove('achieved_goal')
        keys.remove('desired_goal')
        # keys.remove('action')
        keys.sort()
        
        # Concatenate inputs
        x = th.cat([obs[_x] for _x in keys], dim=-1)  # [batch_size, seq_len, feature_dim]
        
        # Reshape input to match transformer's expected shape [batch_size, seq_len, enc_in]
        batch_size = x.size(0)
        seq_len = x.size(1)
        x = x.reshape(batch_size, seq_len, -1)
        
        # Forward through ITransformer
        logits = self.transformer(x, None, None, None)
        return logits

class MultiInputPolicy(SACPolicy):
    """
    Policy class (with both actor and critic) for SAC.

    :param observation_space: Observation space
    :param action_space: Action space
    :param lr_schedule: Learning rate schedule (could be constant)
    :param net_arch: The specification of the policy and value networks.
    :param activation_fn: Activation function
    :param use_sde: Whether to use State Dependent Exploration or not
    :param log_std_init: Initial value for the log standard deviation
    :param use_expln: Use ``expln()`` function instead of ``exp()`` when using gSDE to ensure
        a positive standard deviation (cf paper). It allows to keep variance
        above zero and prevent it from growing too fast. In practice, ``exp()`` is usually enough.
    :param clip_mean: Clip the mean output when using gSDE to avoid numerical instability.
    :param features_extractor_class: Features extractor to use.
    :param normalize_images: Whether to normalize images or not,
         dividing by 255.0 (True by default)
    :param optimizer_class: The optimizer to use,
        ``th.optim.Adam`` by default
    :param optimizer_kwargs: Additional keyword arguments,
        excluding the learning rate, to pass to the optimizer
    :param n_critics: Number of critic networks to create.
    :param share_features_extractor: Whether to share or not the features extractor
        between the actor and the critic (this saves computation time)
    """

    def __init__(
        self,
        observation_space: spaces.Space,
        action_space: spaces.Box,
        lr_schedule: Schedule,
        net_arch: Optional[Union[List[int], Dict[str, List[int]]]] = None,
        activation_fn: Type[nn.Module] = nn.ReLU,
        use_sde: bool = False,
        log_std_init: float = -3,
        use_expln: bool = False,
        clip_mean: float = 2.0,
        features_extractor_class: Type[BaseFeaturesExtractor] = CombinedExtractor,
        features_extractor_kwargs: Optional[Dict[str, Any]] = None,
        normalize_images: bool = True,
        optimizer_class: Type[th.optim.Optimizer] = th.optim.Adam,
        optimizer_kwargs: Optional[Dict[str, Any]] = None,
        n_critics: int = 2,
        share_features_extractor: bool = False,
        # my params 
        causal_hidden_dim :int = 128,
        causal_out_dim: int = 6,
        exponential_smoothing:float =0.0
    ):
        self.causal_hidden_dim = causal_hidden_dim
        self.causal_out_dim = causal_out_dim
        self.action_dim = get_action_dim(action_space)
        obs_shapes = get_obs_shape(observation_space)
        self.observation_dim = sum([obs_shape[0] for obs_shape in obs_shapes.values()])
        super().__init__(
            observation_space,
            action_space,
            lr_schedule,
            net_arch,
            activation_fn,
            use_sde,
            log_std_init,
            use_expln,
            clip_mean,
            features_extractor_class,
            features_extractor_kwargs,
            normalize_images,
            optimizer_class,
            optimizer_kwargs,
            n_critics,
            share_features_extractor,
        )

    def _build(self, lr_schedule: Schedule) -> None:
        super()._build(lr_schedule=lr_schedule)

        # encoder
        trajectory_space = deepcopy(self.observation_space)
        del trajectory_space.spaces['causal']
        trajectory_space = deepcopy(trajectory_space)
        trajectory_space['action'] = spaces.Box(-10,10,(self.action_dim,),dtype=np.float32)

        causal_space = spaces.Box(-10,10,(self.causal_out_dim,),dtype=np.float32)
        self.encoder = EncoderActionEffect(trajectory_space, causal_space, hidden_dim=self.causal_hidden_dim).to(self.device)
        self.encoder_target = EncoderActionEffect(trajectory_space, causal_space, hidden_dim=self.causal_hidden_dim).to(self.device)
        self.encoder_target.load_state_dict(self.encoder.state_dict())
        self.encoder_target.set_training_mode(False)
        self.encoder.optimizer = self.optimizer_class(
            self.encoder.parameters(),
            lr=lr_schedule(1),  # type: ignore[call-arg]
            **self.optimizer_kwargs,
        )

    def _get_constructor_parameters(self):
        data = super()._get_constructor_parameters()

        data.update(
            dict(
                causal_hidden_dim = self.causal_hidden_dim,
                causal_out_dim = self.causal_out_dim,
            )
        )
        return data
    
    def rnn_encoder_predict(self, observation):
        self.set_training_mode(False)

        assert len(observation['hidden_h'].shape) == 2
        assert len(observation['observation'].shape) == 2

        causal_keys = {'hidden_c','hidden_h','causal'}
        encoder_observation = {k:v for k,v in observation.items() if k not in causal_keys}
        encoder_hidden_h = {'hidden_h': observation['hidden_h']}
        encoder_hidden_c = {'hidden_c': observation['hidden_c']}
        
        encoder_observation, _ = self.obs_to_tensor(encoder_observation)
        encoder_hidden_h, _ = self.obs_to_tensor(encoder_hidden_h)
        encoder_hidden_c, _ = self.obs_to_tensor(encoder_hidden_c)

        encoder_logits, (encoder_hidden_h, encoder_hidden_c) = \
            self.encoder.forward_one_step(encoder_observation, h=encoder_hidden_h, c=encoder_hidden_c)
        
        state = (encoder_logits.detach().cpu().numpy(),
                 encoder_hidden_h.detach().cpu().numpy(),
                 encoder_hidden_c.detach().cpu().numpy())
        return state
    
    def predict(
        self,
        observation: Union[np.ndarray, Dict[str, np.ndarray]],
        state: Optional[Tuple[np.ndarray, ...]] = None,
        episode_start: Optional[np.ndarray] = None,
        deterministic: bool = False,
    ) -> Tuple[np.ndarray, Optional[Tuple[np.ndarray, ...]]]:
        """
        Get the policy action from an observation (and optional hidden state).
        Includes sugar-coating to handle different observations (e.g. normalizing images).

        :param observation: the input observation
        :param state: The last hidden states (can be None, used in recurrent policies)
        :param episode_start: The last masks (can be None, used in recurrent policies)
            this correspond to beginning of episodes,
            where the hidden states of the RNN must be reset.
        :param deterministic: Whether or not to return deterministic actions.
        :return: the model's action and the next hidden state
            (used in recurrent policies)
        """
        # Switch to eval mode (this affects batch norm / dropout)
        self.set_training_mode(False)

        _observation = {}
        for key in observation:
            if key not in {'action', 'hidden_c','hidden_h'}:
                _observation[key] = observation[key]
        _observation, vectorized_env = self.obs_to_tensor(_observation)

        with th.no_grad():
            actions = self._predict(_observation, deterministic=deterministic)
        # Convert to numpy, and reshape to the original action shape
        actions = actions.cpu().numpy().reshape((-1, *self.action_space.shape))

        if isinstance(self.action_space, spaces.Box):
            if self.squash_output:
                # Rescale to proper domain when using squashing
                actions = self.unscale_action(actions)
            else:
                # Actions could be on arbitrary scale, so clip the actions to avoid
                # out of bound error (e.g. if sampling from a Gaussian distribution)
                actions = np.clip(actions, self.action_space.low, self.action_space.high)

        # # Remove batch dimension if needed
        # if not vectorized_env:
        #     actions = actions.squeeze(axis=0)
        return actions, state

    def obs_to_tensor(self, observation: Union[np.ndarray, Dict[str, np.ndarray]]) -> Tuple[th.Tensor, bool]:
        """
        Convert an input observation to a PyTorch tensor that can be fed to a model.
        Includes sugar-coating to handle different observations (e.g. normalizing images).

        :param observation: the input observation
        :return: The observation as PyTorch tensor
            and whether the observation is vectorized or not
        """
        vectorized_env = False
        observation = obs_as_tensor(observation, self.device)
        return observation, vectorized_env

    def set_training_mode(self, mode: bool) -> None:
        self.encoder.set_training_mode(mode)
        return super().set_training_mode(mode)

class TransformerEncoder(nn.Module):
    def __init__(self, input_dim, hidden_dim, nhead=4, num_layers=2, dropout=0.1):
        super().__init__()
        
        # Input projection layer to match d_model dimension
        self.input_proj = nn.Linear(input_dim, hidden_dim)
        
        # Layer normalization and positional encoding
        self.layer_norm = nn.LayerNorm(hidden_dim)
        self.pos_encoder = nn.Parameter(torch.zeros(1, 1000, hidden_dim))  # Max sequence length of 1000
        
        # Transformer encoder layers
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=hidden_dim,
            nhead=nhead,
            dim_feedforward=hidden_dim * 4,
            dropout=dropout,
            batch_first=True  # (batch, seq, feature)
        )
        self.transformer = nn.TransformerEncoder(encoder_layer, num_layers=num_layers)
        
        # Store config
        self.hidden_dim = hidden_dim
        
    def forward(self, x, mask=None):
        # Input shape: (batch_size, seq_len, input_dim)
        batch_size, seq_len = x.shape[0], x.shape[1]
        
        # Project input to hidden dimension
        x = self.input_proj(x)  # Shape: (batch_size, seq_len, hidden_dim)
        
        # Add positional encoding
        x = x + self.pos_encoder[:, :seq_len, :]
        
        # Apply layer normalization
        x = self.layer_norm(x)
        
        # Create attention mask if needed
        if mask is not None:
            # Convert boolean mask to float mask where True = -inf (masked positions)
            mask = mask.float().masked_fill(mask == 0, float('-inf')).masked_fill(mask == 1, float(0.0))
        
        # Pass through transformer
        # Shape remains (batch_size, seq_len, hidden_dim)
        output = self.transformer(x, src_key_padding_mask=mask)
        
        return output  # Shape: (batch_size, seq_len, hidden_dim)



